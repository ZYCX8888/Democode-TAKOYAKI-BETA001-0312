#define FPS 60
#define SCREEN_WIDTH 256
#define SCREEN_HEIGHT 240

void play();
